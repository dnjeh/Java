package client;

public class Sender extends Thread {

}
